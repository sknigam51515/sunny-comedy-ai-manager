# Sunny Comedy AI Manager — Android Starter Project

यह Android Studio / Gradle के लिए शुरुआती Kotlin + Jetpack Compose प्रोजेक्ट है।

## अभी क्या तैयार है
- Sunny Comedy नाम और dark + yellow dashboard
- Home, Scripts, SEO और Upload स्क्रीन के शुरुआती UI
- ऐप का package ID: `com.sunny.comedy.manager`
- सुरक्षित integration के लिए placeholders और यह README

## जरूरी सच्चाई
यह अभी **पूरा काम करने वाला YouTube automation ऐप या APK नहीं है**। यह Android source starter है। AI script/SEO के लिए backend/API और YouTube upload/analytics के लिए Google OAuth + YouTube Data API integration अभी configure करना होगा। कोई API key या Google password इस प्रोजेक्ट में शामिल नहीं है।

## APK बनाने के लिए
1. Android Studio में इस project folder को खोलें।
2. Gradle sync पूरा होने दें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. Debug APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

फोन पर ही build करने के लिए compatible Android IDE/build service की जरूरत होगी; इस ZIP से अपने आप APK install नहीं होगा।

## YouTube integration का अगला चरण
1. Google Cloud Console में project बनाएं।
2. YouTube Data API v3 enable करें।
3. OAuth consent screen और Android OAuth client configure करें।
4. ऐप में Google sign-in/OAuth flow जोड़ें और न्यूनतम scopes मांगें।
5. Upload के लिए `youtube.upload`; analytics के लिए उपयुक्त read-only analytics scope रखें।
6. API secrets को APK में hard-code न करें। AI provider key को secure backend पर रखें।
7. पहले private/unlisted test upload से जांचें; public upload से पहले user confirmation रखें।

## सुरक्षा
- Gmail password या OTP कभी न मांगें।
- User approval के बिना public video upload न करें।
- Copyrighted songs/clips का अनधिकृत re-upload न करें।
- Viral views की guarantee संभव नहीं है।
