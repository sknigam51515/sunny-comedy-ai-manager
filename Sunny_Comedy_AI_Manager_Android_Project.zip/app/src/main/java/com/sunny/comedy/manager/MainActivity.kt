package com.sunny.comedy.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101114)
private val Gold = Color(0xFFFFC928)
private val Panel = Color(0xFF202228)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SunnyApp() }
    }
}

@Composable
fun SunnyApp() {
    var selected by remember { mutableStateOf("Dashboard") }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            background = Ink,
            surface = Panel,
            onPrimary = Ink,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Scripts", "SEO", "Upload").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "Home" -> Icons.Default.Home
                                        "Scripts" -> Icons.Default.EditNote
                                        "SEO" -> Icons.Default.Search
                                        else -> Icons.Default.CloudUpload
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("SUNNY COMEDY", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        when(selected) {
                            "Scripts" -> "Comedy Script Studio"
                            "SEO" -> "YouTube SEO Assistant"
                            "Upload" -> "Video Upload Center"
                            else -> "AI Channel Manager"
                        },
                        color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold
                    )
                    Text("Your channel. Your creativity.", color = Color.LightGray)
                }
                when(selected) {
                    "Scripts" -> {
                        item { InfoCard("Script Generator", "Topic, hook, dialogues aur punchline ke liye AI service connect karni hogi.") }
                        item { ActionCard("Create comedy script", "Abhi demo screen hai; AI API connect hone par script generate hogi.") }
                    }
                    "SEO" -> {
                        item { InfoCard("SEO Assistant", "Title, description, tags aur hashtags ka draft banane ka section.") }
                        item { ActionCard("Generate SEO pack", "SEO suggestions ko upload se pehle review karna hoga.") }
                    }
                    "Upload" -> {
                        item { InfoCard("YouTube connection", "Google OAuth aur YouTube Data API setup hone ke baad upload enable hoga.") }
                        item { ActionCard("Connect YouTube", "Connection abhi configured nahi hai. README mein setup steps hain.") }
                        item { Text("Safety: password ya OTP app mein kabhi enter na karein.", color = Gold) }
                    }
                    else -> {
                        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("30", "Day plan", Modifier.weight(1f))
                            StatCard("0", "Uploaded here", Modifier.weight(1f))
                        } }
                        item { InfoCard("Channel status", "YouTube account abhi connect nahi hua hai.") }
                        item { ActionCard("Comedy ideas", "College life • Desi friends • Family comedy • Everyday situations") }
                        item { ActionCard("Thumbnail maker", "Thumbnail design workspace — image generation service baad mein connect hogi.") }
                        item { ActionCard("Analytics", "Views, retention aur swipe metrics YouTube API connect hone ke baad dikhaye jayenge.") }
                    }
                }
                item {
                    Text("Version 0.1 • Starter project", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(body, color = Color.LightGray)
        }
    }
}

@Composable
fun ActionCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF292C33)), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(title, fontWeight = FontWeight.Bold, color = Color.White)
                Text(body, color = Color.LightGray, fontSize = 13.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Gold)
        }
    }
}

@Composable
fun StatCard(number: String, label: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(number, color = Gold, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text(label, color = Color.LightGray, fontSize = 12.sp)
        }
    }
}
